package com.rbu;

public class HeloWorld
{
	public static void main(String[] args) 
	{
		System.out.println("HelloWorld");	
		System.out.println("Good Morning");	
	}

}
