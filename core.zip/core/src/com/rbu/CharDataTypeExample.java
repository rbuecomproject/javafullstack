package com.rbu;

public class CharDataTypeExample {

	public static void main(String[] args) {
		char letter1 = 'I'; //2byte
		char letter2 = 'N';
		char letter3 = 'D';
		char letter4 = 'I';
		char letter5 = 'A';
		char letter6 = 'स';
		System.out.println(letter1);
		System.out.println(letter2);
		System.out.println(letter3);
		System.out.println(letter4);
		System.out.println(letter5);
		System.out.println(letter6);
		
		String name="INDIA";
		System.out.println(name);
		String hindiword="मनुष्यों";
		System.out.println(hindiword);
		

	}

}
