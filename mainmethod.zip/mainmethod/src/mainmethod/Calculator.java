package mainmethod;

public class Calculator {
	
	public static void main(String[] args) {
		int a=Integer.parseInt(args[0]);
		int b=Integer.parseInt(args[1]);
		Calculator link=new Calculator();//create a object helps you like link
		link.add(a,b);
//		link.sub(5000, 500);
//		link.mul(365, 500);
//		link.div(500,5);
		
	}
	
	public void add(int a,int b) {
		System.out.println(a+b);
	}
	
	public void sub(int a,int b) {
		System.out.println(a-b);
	}
	
	public void mul(int a,int b) {
		System.out.println(a*b);
	}
	
	public void div(int a,int b) {
		System.out.println(a/b);
	}
	

}
