package mainmethod;

//eclipse will compile automatically
public class Main {

	public static void main(String[] arg) {
		// System.out.println("Helloworld");
		// to handle realtime business A class for each operation or A method
		Main link=new Main();//create object to call methods of your class
		link.searchProduct();
		link.selectProduct();
		link.addItemsToKart();
		link.buyProduct();
		link.deliverProduct();
	}

	public void searchProduct() {
		System.out.println("search product..");
	}

	public void selectProduct() {
		System.out.println("select product..");
	}

	public void addItemsToKart() {
		System.out.println("add to kart ..");
	}

	public void buyProduct() {
		System.out.println("buy product");
	}

	public void deliverProduct() {
		System.out.println("delivery product..");
	}

}
